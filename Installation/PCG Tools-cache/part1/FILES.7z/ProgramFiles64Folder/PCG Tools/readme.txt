﻿PCG Tools

Terms of Usage

PCG Tools is a free application, however the executable and the source code may never be used for commercial reasons.
Also the application may not be spread except by the developer. It may not be uploaded to web sites, peer to peer networks, spread by email or by other means without permission of the developer. 
The reason for this, is that the developer maintains a list of people who are using PCG Tools and when a new update is available, it will be send to everybody on this update list, to make sure everybody always receives the latest version.
This application is not affiliated by Korg, so requests, bugs, wishes, questions etc. should be directed to michel.keijzers@hotmail or being posted on the main PCG Tools (www.korgforums.com/forum/phpBB2/viewtopic.php?t=63765)  thread or one of the model specific threads at www.korgforums.com. (see paragraph 1.4).

WPF MDI
This application uses third party source code. The license can be read in file wpfmdi_license.txt.

Notice
The developer reserves the right to make improvements or changes in the software product and the manual at any time and without notice.

Disclaimer
THE DEVELOPER, MAKES NO WARRANTIES, EITHER EXPRESSED OR IMPLIED, WITH RESPECT TO THIS MANUAL OR WITH RESPECT TO THE SOFTWARE DESCRIBED IN THIS MANUAL, ITS QUALITY, PERFORMANCE MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE.
THE APPLICATION AND MANUABL IS PUBLISHED AS IS. IN NO EVENT SHALL THE DEVELOPER BE LIABLE FOR INCIDENTAL OR SEQUENTIAL CORRUPTION OF FILES TOUCHED BY THIS SOFTWARE.

© 2011-2015 Michel Keijzers (MikeSoft)

All rights reserved. 
